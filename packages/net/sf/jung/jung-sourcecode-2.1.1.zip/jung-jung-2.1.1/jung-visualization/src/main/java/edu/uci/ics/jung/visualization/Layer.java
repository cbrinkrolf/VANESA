package edu.uci.ics.jung.visualization;

public enum Layer {
	LAYOUT, VIEW
}
