package edu.uci.ics.jung.visualization.spatial;

import java.util.Collection;

import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.util.EdgeType;
import edu.uci.ics.jung.graph.util.Pair;

public class AggregateGraph<V, E> implements Graph<V, E> {

	
//	@Override
	public boolean addEdge(E e, V v1, V v2) {
		// TODO Auto-generated method stub
		return false;
	}

//	@Override
	public boolean addEdge(E e, V v1, V v2, EdgeType edgeType) {
		// TODO Auto-generated method stub
		return false;
	}

//	@Override
	public V getDest(E directedEdge) {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
	public Pair<V> getEndpoints(E edge) {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
	public Collection<E> getInEdges(V vertex) {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
	public V getOpposite(V vertex, E edge) {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
	public Collection<E> getOutEdges(V vertex) {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
	public int getPredecessorCount(V vertex) {
		// TODO Auto-generated method stub
		return 0;
	}

//	@Override
	public Collection<V> getPredecessors(V vertex) {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
	public V getSource(E directedEdge) {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
	public int getSuccessorCount(V vertex) {
		// TODO Auto-generated method stub
		return 0;
	}

//	@Override
	public Collection<V> getSuccessors(V vertex) {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
	public int inDegree(V vertex) {
		// TODO Auto-generated method stub
		return 0;
	}

//	@Override
	public boolean isDest(V vertex, E edge) {
		// TODO Auto-generated method stub
		return false;
	}

//	@Override
	public boolean isPredecessor(V v1, V v2) {
		// TODO Auto-generated method stub
		return false;
	}

//	@Override
	public boolean isSource(V vertex, E edge) {
		// TODO Auto-generated method stub
		return false;
	}

//	@Override
	public boolean isSuccessor(V v1, V v2) {
		// TODO Auto-generated method stub
		return false;
	}

//	@Override
	public int outDegree(V vertex) {
		// TODO Auto-generated method stub
		return 0;
	}

//	@Override
	public boolean addEdge(E edge, Collection<? extends V> vertices) {
		// TODO Auto-generated method stub
		return false;
	}

//	@Override
	public boolean addEdge(E edge, Collection<? extends V> vertices,
			EdgeType edgeType) {
		// TODO Auto-generated method stub
		return false;
	}

//	@Override
	public boolean addVertex(V vertex) {
		// TODO Auto-generated method stub
		return false;
	}

//	@Override
	public boolean containsEdge(E edge) {
		// TODO Auto-generated method stub
		return false;
	}

//	@Override
	public boolean containsVertex(V vertex) {
		// TODO Auto-generated method stub
		return false;
	}

//	@Override
	public int degree(V vertex) {
		// TODO Auto-generated method stub
		return 0;
	}

//	@Override
	public E findEdge(V v1, V v2) {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
	public Collection<E> findEdgeSet(V v1, V v2) {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
	public EdgeType getDefaultEdgeType() {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
	public int getEdgeCount() {
		// TODO Auto-generated method stub
		return 0;
	}

//	@Override
	public int getEdgeCount(EdgeType edgeType) {
		// TODO Auto-generated method stub
		return 0;
	}

//	@Override
	public EdgeType getEdgeType(E edge) {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
	public Collection<E> getEdges() {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
	public Collection<E> getEdges(EdgeType edgeType) {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
	public int getIncidentCount(E edge) {
		// TODO Auto-generated method stub
		return 0;
	}

//	@Override
	public Collection<E> getIncidentEdges(V vertex) {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
	public Collection<V> getIncidentVertices(E edge) {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
	public int getNeighborCount(V vertex) {
		// TODO Auto-generated method stub
		return 0;
	}

//	@Override
	public Collection<V> getNeighbors(V vertex) {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
	public int getVertexCount() {
		// TODO Auto-generated method stub
		return 0;
	}

//	@Override
	public Collection<V> getVertices() {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
	public boolean isIncident(V vertex, E edge) {
		// TODO Auto-generated method stub
		return false;
	}

//	@Override
	public boolean isNeighbor(V v1, V v2) {
		// TODO Auto-generated method stub
		return false;
	}

//	@Override
	public boolean removeEdge(E edge) {
		// TODO Auto-generated method stub
		return false;
	}

//	@Override
	public boolean removeVertex(V vertex) {
		// TODO Auto-generated method stub
		return false;
	}

}
